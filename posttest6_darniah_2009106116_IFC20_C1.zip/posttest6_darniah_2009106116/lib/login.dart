import 'package:flutter/material.dart';
import 'package:posttest6_darniah_2009106116/main.dart';
import 'package:posttest6_darniah_2009106116/menuawal.dart';

void main() {
  runApp(const Login());
}

class Login extends StatelessWidget {
  const Login({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // Try running your application with "flutter run". You'll see the
        // application has a blue toolbar. Then, without quitting the app, try
        // changing the primarySwatch below to Colors.green and then invoke
        // "hot reload" (press "r" in the console where you ran "flutter run",
        // or simply save your changes to "hot reload" in a Flutter IDE).
        // Notice that the counter didn't reset back to zero; the application
        // is not restarted.
        primarySwatch: Colors.deepOrange,
      ),
      home: const Loginform(),
    );
  }
}

class Loginform extends StatefulWidget {
  const Loginform({Key? key}) : super(key: key);

  @override
  // ignore: no_logic_in_create_state
  State<Loginform> createState() => _Loginform();
}

class _Loginform extends State<Loginform> {
  TextEditingController _email = TextEditingController();
  TextEditingController _password = TextEditingController();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("MY Profil"),
          backgroundColor: Color.fromARGB(255, 216, 147, 228),
        ),
        body: Container(
          decoration: BoxDecoration(color: Color.fromRGBO(244, 171, 196, 1)),
          child: ListView(
            children: [
              Column(children: [
                Container(
                  margin: EdgeInsets.only(top: 20, bottom: 20),
                  child: Text("Selamat Datang Di Daftar Resep Makanan",
                      style: TextStyle(
                          fontSize: 50,
                          color: Color.fromARGB(255, 255, 255, 255),
                          shadows: [
                            Shadow(
                              color: Colors.black,
                              offset: Offset(2, 5),
                            )
                          ])),
                ),
                TextField(
                  controller: _email,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: "Email",
                    hintText: "Masukan Email anda",
                  ),
                ),
                SizedBox(
                  height: 30,
                ),
                TextFormField(
                  controller: _password,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: "Password",
                    hintText: "Masukan Password Anda",
                  ),
                ),
                Container(
                    margin: EdgeInsets.only(top: 20),
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        primary: Color.fromARGB(255, 216, 147, 228),
                      ),
                      onPressed: () => submit(
                        context,
                        _email.text,
                        _password.text,
                      ),
                      child: Text("Login"),
                    )),
              ])
            ],
          ),
        ));
  }
}

void submit(BuildContext context, String email, String password) {
  if (email.isEmpty || password.isEmpty) {
    final snackBar = SnackBar(
      duration: const Duration(seconds: 5),
      content: Text("Email dan password harus diisi"),
      backgroundColor: Colors.red,
    );

    ScaffoldMessenger.of(context).showSnackBar(snackBar);
    return;
  }
  AlertDialog alert = AlertDialog(
    title: Text("Login Berhasil"),
    content: Container(
      alignment: Alignment.bottomCenter,
      child: Text("Selamat Anda Berhasil login"),
      decoration: BoxDecoration(
        image: DecorationImage(
          image: AssetImage('assets/menutampil.jpg'),
        ),
      ),
    ),
    actions: [
      TextButton(
        child: Text('Masuk'),
        onPressed: () => Navigator.push(
            context, MaterialPageRoute(builder: (context) => DRM())),
      ),
    ],
  );

  showDialog(context: context, builder: (context) => alert);
  return;
}
