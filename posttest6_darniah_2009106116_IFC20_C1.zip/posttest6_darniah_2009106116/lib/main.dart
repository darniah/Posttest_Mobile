import 'package:flutter/material.dart';
import 'package:posttest6_darniah_2009106116/menuawal.dart';
import 'package:posttest6_darniah_2009106116/person.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Snack(),
    );
  }
}

class DRM extends StatelessWidget {
  const DRM({Key? key}) : super(key: key);

  Widget container1() {
    return Container(
      child: Center(
        child: Text(
          'Resep Cookies',
          style: TextStyle(
            color: Colors.white,
            fontSize: 15,
            fontStyle: FontStyle.italic,
          ),
        ),
      ),
      padding: EdgeInsets.symmetric(vertical: 20, horizontal: 50),
      margin: EdgeInsets.all(20),
      width: 200,
      height: 200,
      decoration: BoxDecoration(
        gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: const <Color>[
              Color.fromARGB(255, 175, 112, 76),
              Colors.white
            ]),
        borderRadius: BorderRadius.circular(20),
        image: DecorationImage(image: AssetImage('assets/a.jpeg')),
        boxShadow: const [
          BoxShadow(
            color: Colors.black45,
            spreadRadius: 5,
            blurRadius: 5,
            offset: Offset(5, 5), // changes position of shadow
          )
        ],
      ),
    );
  }

  Widget container2() {
    return Container(
      child: Center(
        child: Text(
          'Resep Brownies',
          style: TextStyle(
            color: Colors.black,
            fontSize: 14,
            fontStyle: FontStyle.italic,
          ),
        ),
      ),
      padding: EdgeInsets.symmetric(vertical: 20, horizontal: 50),
      margin: EdgeInsets.all(20),
      width: 200,
      height: 200,
      decoration: BoxDecoration(
        gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: const <Color>[
              Color.fromARGB(255, 202, 166, 45),
              Color.fromARGB(255, 133, 65, 2)
            ]),
        borderRadius: BorderRadius.circular(20),
        image: DecorationImage(image: AssetImage('assets/b.jpeg')),
        boxShadow: const [
          BoxShadow(
            color: Colors.black45,
            spreadRadius: 5,
            blurRadius: 5,
            offset: Offset(5, 5), // changes position of shadow
          )
        ],
      ),
    );
  }

  Widget container3() {
    return Container(
      child: Center(
        child: Text(
          'Resep Soto',
          style: TextStyle(
            color: Colors.black,
            fontSize: 18,
            fontStyle: FontStyle.italic,
          ),
        ),
      ),
      padding: EdgeInsets.symmetric(vertical: 20, horizontal: 50),
      margin: EdgeInsets.all(20),
      width: 200,
      height: 200,
      decoration: BoxDecoration(
        gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: const <Color>[Colors.yellow, Colors.white]),
        borderRadius: BorderRadius.circular(20),
        image: DecorationImage(image: AssetImage('assets/c.jpeg')),
        boxShadow: const [
          BoxShadow(
            color: Colors.black45,
            spreadRadius: 5,
            blurRadius: 5,
            offset: Offset(5, 5), // changes position of shadow
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:
            Text('Daftar Resep Makanan', style: TextStyle(color: Colors.black)),
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => Snack()));
          },
        ),
        actions: [
          IconButton(
              onPressed: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (context) => Person()));
              },
              icon: Icon(Icons.person))
        ],
        flexibleSpace: Container(
          decoration: BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: const <Color>[
                Color.fromARGB(255, 76, 139, 175),
                Color.fromARGB(255, 253, 253, 253)
              ])),
        ),
      ),
      body: Container(
        color: Colors.blueGrey,
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: ListView(
          children: [
            SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  container1(),
                  container2(),
                  container3(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
