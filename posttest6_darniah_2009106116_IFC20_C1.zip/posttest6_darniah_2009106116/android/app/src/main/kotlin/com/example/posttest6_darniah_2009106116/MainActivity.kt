package com.example.posttest6_darniah_2009106116

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
