import 'package:flutter/material.dart';
import 'dart:async';
import 'package:posttest5_darniah_2009106116/login.dart';
import 'package:posttest5_darniah_2009106116/person.dart';

void main() {
  runApp(const Snack());
}

class Snack extends StatelessWidget {
  const Snack({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      home: SplashScreen(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Daftar Resep Makanan"),
          backgroundColor: Color.fromARGB(255, 183, 174, 95),
        ),
        body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage('assets/gambardepan.jpg'), fit: BoxFit.cover),
          ),
          child: Center(
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(primary: Colors.amber),
              child: Text(
                "Masuk Ke Menu Login",
                style: TextStyle(
                  fontSize: 25,
                ),
              ),
              onPressed: () {
                final snackBar = SnackBar(
                    content: Text(
                      "Anda Sudah Masuk Ke menu Login",
                    ),
                    duration: Duration(seconds: 3),
                    padding: EdgeInsets.all(10),
                    backgroundColor: Color.fromARGB(255, 216, 147, 228));
                ScaffoldMessenger.of(context).showSnackBar(snackBar);
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => Loginform()));
              },
            ),
          ),
        ));
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    splashScreenStart();
  }

  splashScreenStart() {
    var duration = const Duration(seconds: 10);
    return Timer(duration, () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => MyHomePage(),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Image.asset(
          "assets/menutampil.jpg",
          fit: BoxFit.cover,
        ),
      ),
    );
  }
}
