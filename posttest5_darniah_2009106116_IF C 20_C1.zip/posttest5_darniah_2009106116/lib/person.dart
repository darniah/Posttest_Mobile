import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // Try running your application with "flutter run". You'll see the
        // application has a blue toolbar. Then, without quitting the app, try
        // changing the primarySwatch below to Colors.green and then invoke
        // "hot reload" (press "r" in the console where you ran "flutter run",
        // or simply save your changes to "hot reload" in a Flutter IDE).
        // Notice that the counter didn't reset back to zero; the application
        // is not restarted.
        primarySwatch: Colors.deepOrange,
      ),
      home: const Person(),
    );
  }
}

class Person extends StatefulWidget {
  const Person({Key? key}) : super(key: key);

  @override
  State<Person> createState() => _Person();
}

enum Gender { unknowm, pria, perempuan }

class _Person extends State<Person> {
  int angka = 0;
  bool isSehat = false;
  Gender? gender = Gender.unknowm;
  String nama = ' ', Email = ' ', No = '';
  final ctrlnama = TextEditingController();
  final ctrlEmail = TextEditingController();
  final ctrlNo = TextEditingController();

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    ctrlnama.dispose();
    ctrlEmail.dispose();
    ctrlNo.dispose();
    super.dispose();
  }

  String getGender(Gender? value) {
    if (value == Gender.pria) {
      return "laki-laki";
    } else if (value == Gender.perempuan) {
      return "perempuan";
    }
    return " ";
  }

  Widget data() {
    return Container(
        child: Column(
      children: [
        Text("My Profile"),
        Text("$nama $Email $No"),
        Text(" ${getGender(gender)}")
      ],
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("MY Profil"),
          backgroundColor: Color.fromARGB(255, 216, 147, 228),
        ),
        body: Container(
          decoration: BoxDecoration(color: Color.fromRGBO(244, 171, 196, 1)),
          child: ListView(
            children: [
              Column(
                children: [
                  Container(
                    margin: EdgeInsets.only(top: 20, bottom: 20),
                    child: Text("Selamat Datang Di Daftar Resep Makanan",
                        style: TextStyle(
                            fontSize: 50,
                            color: Color.fromARGB(255, 255, 255, 255),
                            shadows: [
                              Shadow(
                                color: Colors.black,
                                offset: Offset(2, 5),
                              )
                            ])),
                  ),
                  TextField(
                    controller: ctrlnama,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: "nama",
                      hintText: "Masukan Nama anda untuk login",
                    ),
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  TextFormField(
                    controller: ctrlEmail,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: "Email",
                      hintText: "Masukan Email Anda",
                    ),
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  TextFormField(
                    controller: ctrlNo,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: "No HandPhone",
                      hintText: "Keyword.....",
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 20),
                    child: ElevatedButton(
                        onPressed: () {
                          setState(() {
                            nama = ctrlnama.text;
                            Email = ctrlEmail.text;
                            No = ctrlNo.text;
                          });
                        },
                        child: Text("tampil")),
                  ),
                  ListTile(
                    title: Text("laki-laki"),
                    leading: Radio(
                      groupValue: gender,
                      value: Gender.pria,
                      onChanged: (Gender? value) {
                        setState(() {
                          gender = value;
                        });
                      },
                    ),
                  ),
                  ListTile(
                    title: Text("perempuan"),
                    leading: Radio(
                      groupValue: gender,
                      value: Gender.perempuan,
                      onChanged: (Gender? value) {
                        setState(() {
                          gender = value;
                        });
                      },
                    ),
                  ),
                  data()
                ],
              )
            ],
          ),
        ));
  }
}
