package com.example.posttest5_darniah_2009106116

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
